library(keras)
library(here)
library(cloudml)
# This has been done for VGG16 but can also be adapted for xception or any other model
# ========================================
# Training on the cloud (vgg16)
cloudml_train(here::here("scripts/trial1-train-vgg16.R"), master_type = "standard_p100")

# Setting the path for downloading the files
setwd("trial-model-runs")
getwd()
setwd("/Users/iliaazizi/Desktop/UNIL/Deep Learning/projg05/scripts/")

# Collecting the final re-train model and placing the model in the "results" folder
job_collect("cloudml_2020_05_17_121925104")

# =========================================
# Training on the cloud (densenet201)
cloudml_train(here::here("scripts/trial1-train-densenet201.R"), master_type = "standard_p100")

# =========================================
# Training on the cloud (densenet201)
cloudml_train(here::here("scripts/trial1-train-xception.R"), master_type = "standard_p100")