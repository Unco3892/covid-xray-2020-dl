library(keras)
library(here)
library(cloudml)


# Training on the cloud
cloudml_train(here::here("scripts/trial1.R"), master_type = "standard_p100")

# Setting the path for downloading the files
setwd("scripts")

# Collecting the final re-train model and placing the model in the "results" folder
job_collect("-")


setwd("/Users/iliaazizi/Desktop/UNIL/Deep Learning/projg05/scripts")
