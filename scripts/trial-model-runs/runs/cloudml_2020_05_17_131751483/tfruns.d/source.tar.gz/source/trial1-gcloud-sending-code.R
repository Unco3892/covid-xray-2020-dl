library(keras)
library(here)
library(cloudml)
# This has been done for VGG16 but can also be adapted for xception or any other model
# Please not that after submitting each job you need to set the path to the trial-model-runs folder and then set it back to the scripts directory again

# ========================================
# Training on the cloud (vgg16)
cloudml_train(here::here("scripts/trial1-train-vgg16.R"), master_type = "standard_p100")

# Setting the path for downloading the files
setwd("trial-model-runs")
getwd()
setwd("/Users/iliaazizi/Desktop/UNIL/Deep Learning/projg05/scripts/")

# First trial(with software and seems to be over-fitting because of accuracy of 1) --> job_collect("cloudml_2020_05_17_121925104") 
# Second trial (with sigmoid but also seems to be over-fitting) --> job_collect("cloudml_2020_05_17_124519217")

# =========================================
# Training on the cloud (densenet201)
cloudml_train(here::here("scripts/trial1-train-densenet201.R"), master_type = "standard_p100")
# job_collect("cloudml_2020_05_17_125412295")

# =========================================
# Training on the cloud (xception)
cloudml_train(here::here("scripts/trial2-train-xception.R"), master_type = "standard_p100")

# =========================================
# Training on the cloud (NASNETLarge)
cloudml_train(here::here("scripts/trial1-train-nasnetLarge.R"), master_type = "standard_p100")
